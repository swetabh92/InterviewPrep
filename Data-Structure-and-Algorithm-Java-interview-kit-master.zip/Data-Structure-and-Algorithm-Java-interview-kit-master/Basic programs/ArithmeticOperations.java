package BasicPractice;

public class ArithmeticOperations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double num1 = 5/2;
		System.out.println(num1);   //2.0
		
		int num2 = 5/2;
		System.out.println(num2);	//2
		
		double num3 = 5.0/2.0;
		System.out.println(num3);	//2.5
		
		double num4 = 5.0/2;
		System.out.println(num4);	//2.5
		
		double a=1;
		System.out.println(a);	//1.0
	}

}
//note: Division (�/�) operates differently on integers and on doubles! 
