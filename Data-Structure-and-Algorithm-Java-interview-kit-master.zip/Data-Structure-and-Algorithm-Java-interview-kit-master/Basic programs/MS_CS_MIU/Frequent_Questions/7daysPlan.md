**DAY 1**

even subset  ✅,
twinoid  ✅,
balanced array ,
hasSmallFactors,
fill,
hollow,
is MeeraArray,
meera number

**DAY 2**

bean array,
factor two count,
bunker array,
good spread,
nice array,
isSym symmetric array,
isSub subarray,
evenSpaced

**DAY 3**

count digit, 
even spaced,
wave array,
sum is power,
min distance,
has k small factor,
min prime distance,
count digit

**DAY 4**

isFibonacci,
super array,
fancy number,
maxmin equal,
is121array,
max occur digit,
max distance,
odd heavy

**DAY 5**

paired,
getExponent,
hasSingleMode,
stuff array,
pascal number,
fancy number,
filter array,
dual array

**DAY 6**

bunker number,
odd spaced,
Riley number,
Normal number,
isComplete complete array,
Guthrie number,
Daphne array,
triple array

**DAY 7**

factor equal,
smart number,
isTwin,
set equal,
isContinuousFactored,
count digit,
isCentered,
prime product
