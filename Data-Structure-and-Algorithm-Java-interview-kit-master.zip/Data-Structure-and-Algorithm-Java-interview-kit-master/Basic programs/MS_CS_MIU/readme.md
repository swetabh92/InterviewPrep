
**Note:** *Many solutions here can be optimised using inbuilt functions like Collections, using Hashing in many solutions. As these practice are based on **Arrays** I tried implementing without using any libraries as possible to build up the logic.*


<h2>Top 56 Questions to practice</h2>

| Question | Java implementation |
| --- | --- |
| Even Subset|[Solution]( https://github.com/NirmalSilwal/Data-Structure-and-Algorithm-Java-interview-kit/blob/master/Basic%20programs/MS_CS_MIU/practice_set/EvenSubsetIntPairs.java) |
| Twinoid | [Solution](https://github.com/NirmalSilwal/Data-Structure-and-Algorithm-Java-interview-kit/blob/master/Basic%20programs/MS_CS_MIU/Frequent_Questions/Twinoid.java) |
