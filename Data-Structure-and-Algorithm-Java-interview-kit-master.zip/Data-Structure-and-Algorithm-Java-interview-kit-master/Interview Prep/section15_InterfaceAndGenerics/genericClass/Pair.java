package section15_InterfaceAndGenerics.genericClass;

public class Pair<T> {

	T one;
	T two;
}
