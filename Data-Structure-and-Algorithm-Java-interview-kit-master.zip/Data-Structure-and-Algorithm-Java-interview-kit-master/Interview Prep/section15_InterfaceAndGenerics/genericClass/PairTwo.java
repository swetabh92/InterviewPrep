package section15_InterfaceAndGenerics.genericClass;

public class PairTwo<K, V> {

	K one;
	V two;
}
