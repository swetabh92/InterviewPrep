package section15_InterfaceAndGenerics;

public class Stack implements DynamicStackInterface {

	/* (non-Javadoc)
	 * @see section15_InterfaceAndGenerics.Stack_Interface#push(int)
	 */
	public void push(int item) {
		
	}

	/* (non-Javadoc)
	 * @see section15_InterfaceAndGenerics.Stack_Interface#pop()
	 */
	public int pop() {
		return 0;
	}

	/* (non-Javadoc)
	 * @see section15_InterfaceAndGenerics.DSAInterface#size()
	 */
	public int size() {
		return 0;
	}

	/* (non-Javadoc)
	 * @see section15_InterfaceAndGenerics.DSAInterface#isEmpty()
	 */
	public boolean isEmpty() {
		return false;
	}

	/* (non-Javadoc)
	 * @see section15_InterfaceAndGenerics.DynamicStackInterface#display()
	 */
	public void display() {
		
	}


}
