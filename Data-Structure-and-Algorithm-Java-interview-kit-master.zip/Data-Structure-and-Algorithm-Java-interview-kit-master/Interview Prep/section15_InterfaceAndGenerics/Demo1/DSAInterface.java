package section15_InterfaceAndGenerics;

public interface DSAInterface {

}
