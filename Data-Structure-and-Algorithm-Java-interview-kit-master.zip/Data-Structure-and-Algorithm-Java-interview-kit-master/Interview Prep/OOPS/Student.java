package OOPS;

public class Student {
	
	// data members
	String name;
	int age;
}
