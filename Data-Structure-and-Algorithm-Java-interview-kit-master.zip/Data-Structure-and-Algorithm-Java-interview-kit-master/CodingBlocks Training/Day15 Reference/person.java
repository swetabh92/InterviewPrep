package OOPS;

public class person {

	String name;
	int age;
}
