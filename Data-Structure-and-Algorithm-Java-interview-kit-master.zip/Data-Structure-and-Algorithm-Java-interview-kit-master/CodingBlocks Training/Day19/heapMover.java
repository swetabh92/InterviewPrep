package Lecture19;

import Lecture19.LinkedList.Node;

public class heapMover {

	Node node;

	public heapMover(Node node) {
		this.node = node;
	}
}
