package Lecture23.generics;

// T1 can be of one data type and T2 of another

public class GenericPair2D <T1, T2> {

	T1 one;
	T2 two;
}
