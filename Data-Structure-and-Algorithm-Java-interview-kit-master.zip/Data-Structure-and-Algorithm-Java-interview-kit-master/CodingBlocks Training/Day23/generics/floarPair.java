package Lecture23.generics;

public class floarPair {

	float one;
	float two;
}
