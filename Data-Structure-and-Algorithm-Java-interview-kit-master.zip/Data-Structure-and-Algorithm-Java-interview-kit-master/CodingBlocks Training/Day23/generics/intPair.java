package Lecture23.generics;

// problem: couldn't reuse data types
public class intPair {

	int one;
	int two;
	
}
