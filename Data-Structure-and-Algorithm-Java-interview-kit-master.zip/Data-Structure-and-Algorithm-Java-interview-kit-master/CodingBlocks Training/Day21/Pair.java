package Lecture21;

public class Pair {

	int diameter;
	int height;

	Pair(int diameter, int height) {
		this.diameter = diameter;
		this.height = height;
	}
	
	Pair() {
		
	}
}
