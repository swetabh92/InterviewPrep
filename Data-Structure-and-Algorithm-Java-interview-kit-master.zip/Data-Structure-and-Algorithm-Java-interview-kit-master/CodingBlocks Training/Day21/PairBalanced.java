package Lecture21;

public class PairBalanced {

	int height;
	boolean isbalanced;

	PairBalanced() {

	}

	PairBalanced(int height, boolean isbalanced) {
		this.height = height;
		this.isbalanced = isbalanced;
	}
}
