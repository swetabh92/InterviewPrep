package Lecture15;

public class person {

	public String name;
	public int age;
}
