package Lecture1;

public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hello world");
		System.out.print("Coding Blocks");
		System.out.println("Bye!");
		System.out.print("cursor will go to new line\n");
		System.out.print("tab experiment \t");
		System.out.print("after tab seperated by 4 spaces\n");
		System.out.print("coding\t");
		System.out.print("blocks");

	}

}
