package Lecture1;

public class SimpleInterest {

	public static void main(String[] args) {
		int p = 1000;
		int t = 1;
		int r = 10;
		int si = (p*t*r)/100;
		System.out.println("simple interest is: "+ si);
	}

}
