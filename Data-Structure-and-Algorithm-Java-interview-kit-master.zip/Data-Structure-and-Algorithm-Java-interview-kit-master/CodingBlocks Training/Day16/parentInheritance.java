package Lecture16;

public class parentInheritance {

	int age = 40;
	int rollno = 7;

	public void sing() {
		System.out.println("Inside parent sing menthod");
	}

	public void read() {
		System.out.println("Inside parent read method");
	}
}
