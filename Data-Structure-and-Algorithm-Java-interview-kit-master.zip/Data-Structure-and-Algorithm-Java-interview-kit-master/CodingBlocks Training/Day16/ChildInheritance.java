package Lecture16;

public class ChildInheritance extends parentInheritance {

	int age = 20;
	String name = "Trishna";

	public void read() {
		System.out.println("Inside child read method");
	}

	public void write() {
		System.out.println("Inside child write method");
	}
}
