package com.javatechie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbProcedureFunctionApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbProcedureFunctionApplication.class, args);
	}

}
