package com.techno.town.techie.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudCloudConfigClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudCloudConfigClientApplication.class, args);
	}

}
