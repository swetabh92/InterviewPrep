package com.techno.town.techie.zipkin_service_integration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZipkinServiceIntegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
