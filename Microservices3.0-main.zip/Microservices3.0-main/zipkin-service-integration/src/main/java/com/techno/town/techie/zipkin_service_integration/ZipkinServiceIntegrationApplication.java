package com.techno.town.techie.zipkin_service_integration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZipkinServiceIntegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZipkinServiceIntegrationApplication.class, args);
	}

}
