package openclosedprinciple;

public class Calculator {

    public void calculate(CalculatorOperation operation) {
        operation.performOperation();
    }
}
