package openclosedprinciple;

public interface CalculatorOperation {

    void performOperation();
}
