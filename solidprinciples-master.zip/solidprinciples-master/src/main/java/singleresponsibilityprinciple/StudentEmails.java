package singleresponsibilityprinciple;

public class StudentEmails {
    public void sendEmail() {
        // some logic
    }
}
