package interfacesegregationprinciple.followisp;

public interface Vehicle {
    void setPrice(double price);
    void setColor(String color);

}
