package interfacesegregationprinciple.followisp;

public interface Movable {

    void start();
    void stop();

}
