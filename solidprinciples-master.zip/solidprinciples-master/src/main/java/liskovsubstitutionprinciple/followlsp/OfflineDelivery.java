package liskovsubstitutionprinciple.followlsp;

public class OfflineDelivery extends BookDelivery{
    void getDeliveryLocations() {
        //provide the available delivery locations for the book.
    }
}
