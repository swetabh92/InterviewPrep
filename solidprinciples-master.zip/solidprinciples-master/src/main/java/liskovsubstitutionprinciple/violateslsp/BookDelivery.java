package liskovsubstitutionprinciple.violateslsp;

public class BookDelivery {
    String titles;
    Integer userID;

    void getDeliveryLocations() {
           //provide the available delivery locations for the book.
    }
}
