package dependencyinversionprinciple;

public interface CalculatorOperation {

    void performOperation();
}
