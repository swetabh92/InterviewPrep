import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static java.util.Arrays.sort;

public class Test{
    public static void main(String[] args) {
/*       // output : [Java, Python, C#, Kotlin]
        List<String> listOfLanguages = Arrays.asList("Java", "Python", "C#", "Java", "Kotlin", "Python");

        Map<String, Long> collect = listOfLanguages.stream().
                collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()));

        collect.entrySet().stream().forEach(e-> System.out.println(e.getKey()));*/




                int[] a = {4, 2, 7, 1};
                int[] b = {8, 3, 9, 5};

                // Merge and sort using Java 8 Streams
                int[] mergedAndSorted = IntStream.concat(Arrays.stream(a), Arrays.stream(b))
                        .sorted()
                        .toArray();

                // Print the result
                System.out.println("Merged and sorted array: " + Arrays.toString(mergedAndSorted));
            }
        }




























/*
public class Test {
    public static void main(String[] args) {
        int[] num = {2, 4, 6, 8, 11, 10, 13, 14, 15};

        System.out.println("Prime numbers in the array:");
        for (int n : num) {
            if (isPrime(n)) {
                System.out.print(n + " ");
            }
        }
    }

    // Method to check if a number is prime
    public static boolean isPrime(int number) {
        if (number <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }
}*/
