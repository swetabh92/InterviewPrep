package interfacesegregationprinciple.followisp;



public class Car implements Vehicle, Movable {
    double price;
    String color;

    public void setPrice(double price) {

    }

    public void setColor(String color) {

    }

    public void start() {

    }

    public void stop() {

    }


}
