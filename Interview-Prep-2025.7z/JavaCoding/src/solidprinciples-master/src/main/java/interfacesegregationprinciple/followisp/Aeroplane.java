package interfacesegregationprinciple.followisp;

import interfacesegregationprinciple.violateisp.Vehicle;

public class Aeroplane implements Vehicle, Movable,Flyable {
    double price;
    String color;

    public void setPrice(double price) {

    }

    public void setColor(String color) {

    }

    public void start() {

    }

    public void stop() {

    }

    public void fly() {

    }
}
