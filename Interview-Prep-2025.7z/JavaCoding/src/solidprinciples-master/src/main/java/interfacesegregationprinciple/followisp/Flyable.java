package interfacesegregationprinciple.followisp;

public interface Flyable {

    void fly();
}
