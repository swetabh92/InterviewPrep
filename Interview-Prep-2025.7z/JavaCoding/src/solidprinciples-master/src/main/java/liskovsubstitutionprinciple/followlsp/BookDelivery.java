package liskovsubstitutionprinciple.followlsp;

public class BookDelivery {
    String titles;
    Integer userID;
}
