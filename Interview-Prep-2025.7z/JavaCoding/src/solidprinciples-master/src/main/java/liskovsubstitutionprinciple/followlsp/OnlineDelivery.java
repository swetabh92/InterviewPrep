package liskovsubstitutionprinciple.followlsp;

public class OnlineDelivery extends BookDelivery{
    void getSoftwareOptions() {
        //provide the available software options to deliver audio book.
    }
}
