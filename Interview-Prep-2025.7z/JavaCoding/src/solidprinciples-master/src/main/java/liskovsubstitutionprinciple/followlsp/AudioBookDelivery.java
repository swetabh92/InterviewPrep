package liskovsubstitutionprinciple.followlsp;

import liskovsubstitutionprinciple.violateslsp.BookDelivery;

public class AudioBookDelivery extends OnlineDelivery {

    @Override
    void getSoftwareOptions() {

    }
}
