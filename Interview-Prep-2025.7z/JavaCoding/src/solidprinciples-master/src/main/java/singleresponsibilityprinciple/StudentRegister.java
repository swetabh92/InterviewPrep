package singleresponsibilityprinciple;

public class StudentRegister {

    public void registerStudent() {
        // some logic
    }
}
