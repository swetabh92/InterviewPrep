package singleresponsibilityprinciple;

public class Student {

    public void registerStudent() {
        // some logic
    }

    public void calculate_Student_Results() {
        // some logic
    }

    public void sendEmail() {
        // some logic
    }
}
