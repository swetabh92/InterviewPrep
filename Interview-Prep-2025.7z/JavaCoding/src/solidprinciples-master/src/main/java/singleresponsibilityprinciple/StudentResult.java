package singleresponsibilityprinciple;

public class StudentResult {
    public void calculate_Student_Result() {
        // some logic
    }
}
