package dependencyinversionprinciple;

public class Calculator {

    public double Add(double x, double y) {
        return x + y;
    }

    public double Subtract(double x, double y) {
        return x - y;
    }

    /*public void calculate(CalculatorOperation operation) {
        operation.performOperation();
    }*/
}
