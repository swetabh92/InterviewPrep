package src.java2025practice;

public class ReverseOfString {
    public static void main(String[] args) {
        String s = "Welcome to Java!!";
        System.out.println(s.toString());
    }
}
