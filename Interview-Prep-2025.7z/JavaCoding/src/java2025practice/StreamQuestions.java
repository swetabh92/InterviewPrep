package java2025practice;

public class StreamQuestions {

}
