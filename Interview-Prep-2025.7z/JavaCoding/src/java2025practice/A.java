package java2025practice;

public class A {
    public Object capPrice(){
        System.out.println("parent")  ;
        return 1;
    }

}
//concept of wrapper executed at runtime
class B extends  A {
    public Integer capPrice(){
        System.out.println("parent")  ;
        return 1;
    }
}
//covariant type