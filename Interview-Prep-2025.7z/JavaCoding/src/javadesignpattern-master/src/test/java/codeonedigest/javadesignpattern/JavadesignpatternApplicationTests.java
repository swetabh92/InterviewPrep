package codeonedigest.javadesignpattern;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavadesignpatternApplicationTests {

	@Test
	void contextLoads() {
	}

}
