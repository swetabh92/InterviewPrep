package codeonedigest.javadesignpattern.structural.facade;

public class ClsInvoice {

    public void printInvoice() {
        System.out.println("Printing Invoice");
    }
}
