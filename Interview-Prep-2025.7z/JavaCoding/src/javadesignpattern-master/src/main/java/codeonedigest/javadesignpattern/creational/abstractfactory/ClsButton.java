package codeonedigest.javadesignpattern.creational.abstractfactory;

public class ClsButton implements InterfaceRenderer {
    @Override
    public void render() {
        System.out.println("Button is rendered!!");
    }
}
