package codeonedigest.javadesignpattern.creational.builderpattern;

public class BrickHouse extends House {
    @Override
    public String getRepresentation() {
        return "Building BRICK House";
    }
}
