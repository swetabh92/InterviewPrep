package codeonedigest.javadesignpattern.structural.bridge;

public interface ISwitch {
    void on();
    void off();
}
