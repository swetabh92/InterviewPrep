package codeonedigest.javadesignpattern.behavioral.strategy;

public abstract class ClsStrategy {

    public abstract int calculate(int a, int b);
}
