package codeonedigest.javadesignpattern.creational.abstractfactory;

public class ClsTextBox implements InterfaceRenderer {
    @Override
    public void render() {
        System.out.println("Textbox is rendered!!");
    }
}
