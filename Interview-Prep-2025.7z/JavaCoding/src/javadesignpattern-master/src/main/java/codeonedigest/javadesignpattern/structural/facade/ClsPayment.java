package codeonedigest.javadesignpattern.structural.facade;

public class ClsPayment {
    public void payOnline() {
        System.out.println("Paid Online");
    }
}
