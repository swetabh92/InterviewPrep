package codeonedigest.javadesignpattern.structural.composite;

public interface IUserInterface {

    void draw();
}
