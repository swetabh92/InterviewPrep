package codeonedigest.javadesignpattern.creational.abstractfactory;

public interface InterfaceRenderer {

    void render();
}
