package codeonedigest.javadesignpattern.behavioral.mediator;

public interface Command {
    void land();
}
