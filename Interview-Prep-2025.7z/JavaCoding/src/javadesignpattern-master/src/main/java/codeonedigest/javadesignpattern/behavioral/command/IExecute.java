package codeonedigest.javadesignpattern.behavioral.command;

public abstract class IExecute {

    public String command;

    public abstract void executeCommand();
}
