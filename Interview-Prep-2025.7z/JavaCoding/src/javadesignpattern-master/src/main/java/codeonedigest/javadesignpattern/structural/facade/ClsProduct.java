package codeonedigest.javadesignpattern.structural.facade;

public class ClsProduct {
    public void getDetails(){
        System.out.println("Product Information");
    }
}
