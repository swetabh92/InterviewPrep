package codeonedigest.javadesignpattern.creational.builderpattern;

public abstract class House {

    public abstract String getRepresentation();
}
