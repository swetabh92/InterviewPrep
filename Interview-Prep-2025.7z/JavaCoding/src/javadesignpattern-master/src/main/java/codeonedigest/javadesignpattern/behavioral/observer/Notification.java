package codeonedigest.javadesignpattern.behavioral.observer;

public interface Notification {
    public void sendNotification();
}
