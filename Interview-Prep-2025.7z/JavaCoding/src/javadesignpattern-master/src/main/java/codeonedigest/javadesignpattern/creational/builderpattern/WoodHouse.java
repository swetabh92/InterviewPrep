package codeonedigest.javadesignpattern.creational.builderpattern;

public class WoodHouse extends House {
    @Override
    public String getRepresentation() {
        return "Building WOOD House";
    }
}
