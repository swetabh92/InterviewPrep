public class SeparateZeroesAndOnes {
    public static void main(String[] args) {
        int[] arr = {0, 1, 0, 1, 0, 0, 1, 1};

        // Call the function to separate zeros and ones
        separateZerosAndOnes(arr);

        // Print the result
        for (int num : arr) {
            System.out.print(num + " ");
        }
    }

    public static void separateZerosAndOnes(int[] arr) {
        int left = 0;  // Pointer to track the leftmost position
        int right = arr.length - 1;  // Pointer to track the rightmost position

        while (left < right) {
            // Increment left pointer if current element is 0
            if (arr[left] == 0) {
                left++;
            }
            // Decrement right pointer if current element is 1
            else if (arr[right] == 1) {
                right--;
            }
            // Swap elements if left points to 1 and right points to 0
            else {
                int temp = arr[left];
                arr[left] = arr[right];
                arr[right] = temp;

                // Move both pointers
                left++;
                right--;
            }
        }
    }
}