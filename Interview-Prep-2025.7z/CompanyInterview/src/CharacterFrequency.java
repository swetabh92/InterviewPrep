import java.util.stream.Collectors;
import java.util.LinkedHashMap;
import java.util.Map;

public class CharacterFrequency {
    public static void main(String[] args) {
        String input = "aaabbbcc";

        // Process input string using Java 8 streams
        String output = input.chars()
                .mapToObj(c -> (char) c) // Convert int stream to char stream
                .collect(Collectors.groupingBy(c -> c, LinkedHashMap::new, Collectors.counting()))
                .entrySet()
                .stream()
                .map(entry -> entry.getKey() + "" + entry.getValue()) // Build key-value pairs
                .collect(Collectors.joining());

        System.out.println(output);
    }
}