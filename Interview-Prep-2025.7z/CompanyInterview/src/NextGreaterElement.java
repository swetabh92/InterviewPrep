/*Find the next greater element for every element in given array
        Input : arr[] = [1,3,2,4]
        Output :[3,4,4,-1] */
import java.util.Stack;

public class NextGreaterElement {

    public static void main(String[] args) {
        int[] arr = {1, 3, 2, 4};
        int[] result = findNextGreaterElements(arr);

        // Print the result array
        for (int num : result) {
            System.out.print(num + " ");
        }
    }

    public static int[] findNextGreaterElements(int[] arr) {
        int n = arr.length;
        int[] result = new int[n];

        // Iterate through each element in the array
        for (int i = 0; i < n; i++) {
            // Assume no greater element is found
            result[i] = -1;

            // Check the elements to the right of the current element
            for (int j = i + 1; j < n; j++) {
                if (arr[j] > arr[i]) {
                    result[i] = arr[j];
                    break; // Exit the loop once the next greater element is found
                }
            }
        }

        return result;
    }
}


/*public class NextGreaterElement {
    public static int[] nextGreaterElement(int[] arr) {
        int n = arr.length;
        int[] result = new int[n]; // To store the result
        Stack<Integer> stack = new Stack<>(); // Stack to store next greater elements

        // Traverse the array from right to left
        for (int i = n - 1; i >= 0; i--) {
            // Remove elements from the stack that are smaller than or equal to the current element
            while (!stack.isEmpty() && stack.peek() <= arr[i]) {
                stack.pop();
            }

            // If the stack is not empty, the top element is the next greater element
            result[i] = stack.isEmpty() ? -1 : stack.peek();

            // Push the current element onto the stack
            stack.push(arr[i]);
        }

        return result;
    }

    public static void main(String[] args) {
        int[] arr = {1, 3, 2, 4};
        int[] result = nextGreaterElement(arr);

        // Print the result
        for (int num : result) {
            System.out.print(num + " ");
        }
    }
}*/
/*Find the next greater element for every element in given array
        Input : arr[] = [1,3,2,4]
        Output :[3,4,4,-1]
        Explanation:
Initialization:

result array is initialized to store the output.
Stack<Integer> is used to keep track of the next greater elements during the reverse traversal.
Reverse Traversal:

For each element from right to left, smaller elements are removed from the stack.
If the stack is empty, there is no next greater element for the current value (-1 is assigned).
Otherwise, the top of the stack is the next greater element.
Output:

Print the result array.
Example Execution:
For input: arr = {1, 3, 2, 4}

Start from 4: No greater element -> -1
For 2: Next greater is 4 -> 4
For 3: Next greater is 4 -> 4
For 1: Next greater is 3 -> 3
Output: 3 4 4 -1
        */