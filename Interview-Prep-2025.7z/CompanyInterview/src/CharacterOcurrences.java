import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

class CharacterOccurrences {
    public static void main(String[] args) {
        // Array of words
        String[] words = {"hello", "world", "java", "stream", "example"};

        // Calculate character occurrences
        Map<Character, Long> characterCounts = Arrays.stream(words) // Stream the array of words
                .flatMapToInt(String::chars) // Convert each word into a stream of its characters
                .mapToObj(c -> (char) c) // Convert int stream to Character stream
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        // Print the character occurrences
        characterCounts.forEach((character, count) ->
                System.out.println(character + " : " + count));
    }
}
/*Explanation:
        Input: The program takes an array of words as input.
        Stream Operations:
        Arrays.stream(words): Creates a stream from the array of words.
        flatMapToInt(String::chars): Converts each string into a stream of its characters represented as int values.
        mapToObj(c -> (char) c): Maps the int values back to Character objects.
        collect(Collectors.groupingBy(Function.identity(), Collectors.counting())): Groups the characters and counts their occurrences.
        Output: The program prints each character and its count.
        This approach efficiently calculates the character occurrences using Java 8's functional programming features*/