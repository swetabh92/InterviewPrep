
import java.util.ArrayList;
        import java.util.List;

public class MissingNumbersArray {
    public static void main(String[] args) {
        int[] arr = {1, 3, 4, 6, 7, 9};

        // Define the range (assuming numbers are from 1 to 9)
        int n = 9;

        // Create a list to track missing numbers
        List<Integer> missingNumbers = new ArrayList<>();

        // Iterate through the range from 1 to n
        for (int i = 1; i <= n; i++) {
            boolean found = false;

            // Check if the current number is in the array
            for (int num : arr) {
                if (num == i) {
                    found = true;
                    break;
                }
            }

            // If the number is not found, add it to the list of missing numbers
            if (!found) {
                missingNumbers.add(i);
            }
        }

        // Calculate the sum of missing numbers
        int missingSum = 0;
        for (int num : missingNumbers) {
            missingSum += num;
        }

        // Print the missing numbers and their sum
        System.out.println("Missing numbers: " + missingNumbers);
        System.out.println("Sum of missing numbers: " + missingSum);
    }
}
