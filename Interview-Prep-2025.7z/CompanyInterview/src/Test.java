import java.util.ArrayList;

public class Test{
    public static void main(String[] args) {
        int arr[] = {1,3,4,6,7,9};
        missingNumber(arr);
    }

    private static void missingNumber(int[] arr) {
       int[] nonMissingNumber = arr;
//       int length = nonMissingNumber.length;
      int range = 9;
        ArrayList<Integer> missingNumber = new ArrayList<>();

        for (int i = 1; i <range ; i++) {

            boolean found = false;

            for (int num : arr) {
                if (num == i) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                missingNumber.add(i);
            }

        }
        missingNumber.stream().forEach(System.out::print);
    }
}


/*
import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Test {
    public static void main(String[] args) {
      String str =  "This is java coding This is java coding java";

                // Split the string into words and convert it to a stream
                Map<String, Long> wordFrequency = Arrays.stream(str.split(" "))
                        .map(String::toLowerCase) // Convert to lowercase for case-insensitivity
                        .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

                // Print the word frequencies
                wordFrequency.forEach((word, frequency) ->
                        System.out.println(word + " : " + frequency));
            }
        }
        int arr [] = {1, 3, 4, 6, 7, 9};

*/
