public class MissingNumber {
    public static void main(String[] args) {
        int[] arr = {1, 3, 4, 6, 7, 9};


        // Define the range (assuming numbers are from 1 to 9)
        int n = 9;

        // Calculate the expected sum of numbers from 1 to n
        int expectedSum = (n * (n + 1)) / 2;

        // Calculate the actual sum of elements in the array
        int actualSum = 0;
        for (int num : arr) {
            actualSum += num;
        }

        // Find the missing number
        int missingNumber = expectedSum - actualSum;

        System.out.println("The missing number is: " + missingNumber);
    }
}