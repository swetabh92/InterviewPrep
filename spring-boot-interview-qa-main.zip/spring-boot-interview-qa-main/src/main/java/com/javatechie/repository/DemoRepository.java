package com.javatechie.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface DemoRepository {
}
