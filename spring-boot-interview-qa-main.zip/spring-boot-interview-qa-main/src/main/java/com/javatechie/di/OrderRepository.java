package com.javatechie.di;

import org.springframework.stereotype.Repository;

public interface OrderRepository {

    public void saveOrder();
}
