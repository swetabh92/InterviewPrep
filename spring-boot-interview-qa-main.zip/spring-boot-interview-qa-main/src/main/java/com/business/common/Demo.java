package com.business.common;

import org.springframework.stereotype.Component;

@Component
public class Demo {

    public Demo() {
        System.out.println("Demo class scanned !!!!");
    }
}
