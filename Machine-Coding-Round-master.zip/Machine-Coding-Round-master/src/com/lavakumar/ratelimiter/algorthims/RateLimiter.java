package com.lavakumar.ratelimiter.algorthims;

public interface RateLimiter {
    boolean allowRequest();
}
