package com.lavakumar.designfacebook.model;

public class Friends {

}
