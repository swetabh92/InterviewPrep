package com.lavakumar.designfacebook;

import com.lavakumar.designfacebook.repository.UserRepository;

public class Driver {
    public static void main(String[] args) {

        UserRepository userRepository = new UserRepository();

    }
}
