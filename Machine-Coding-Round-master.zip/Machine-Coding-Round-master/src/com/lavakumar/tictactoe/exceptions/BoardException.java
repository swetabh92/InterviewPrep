package com.lavakumar.tictactoe.exceptions;

public class BoardException extends RuntimeException {
    public BoardException(String message){
        super(message);
    }
}
