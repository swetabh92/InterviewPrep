package com.lavakumar.tictactoe.mode;


import com.lavakumar.tictactoe.model.Board;

public interface Print {
    public void printBoard(Board board);
}
