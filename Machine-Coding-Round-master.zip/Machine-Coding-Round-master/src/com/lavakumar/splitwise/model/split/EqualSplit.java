package com.lavakumar.splitwise.model.split;

import com.lavakumar.splitwise.model.User;
import com.lavakumar.splitwise.model.split.Split;

public class EqualSplit extends Split {

    public EqualSplit(User user) {
        super(user);
    }
}