package com.lavakumar.splitwise.model.expense;

public class ExpenseData {
    private String name;

    public ExpenseData(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
