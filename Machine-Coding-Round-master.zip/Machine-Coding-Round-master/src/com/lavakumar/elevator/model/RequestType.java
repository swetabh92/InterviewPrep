package com.lavakumar.elevator.model;

public enum RequestType {
    INSIDE,
    OUTSIDE
}
