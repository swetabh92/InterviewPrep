package com.lavakumar.elevator.model;

public enum Direction {
    IDLE,
    UP,
    DOWN
}
