package com.lavakumar.elevator.model.buttonpanel;

import com.lavakumar.elevator.Request;

public interface ButtonPanel {

    boolean sendInstructionToDispatcher(Request request);

}
