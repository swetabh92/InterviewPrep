package com.lavakumar.elevator.util;

public class Constants {
    public static final int FLOORS = 40;
    public static final int ELEVATORS = 20;
    public static final int CAPACITY_OF_ELEVATOR = 5;
}
