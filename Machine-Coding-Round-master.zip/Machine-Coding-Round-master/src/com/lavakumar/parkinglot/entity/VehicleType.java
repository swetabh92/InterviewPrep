package com.lavakumar.parkinglot.entity;

public enum VehicleType {
    TRUCK,
    BIKE,
    CAR;
}
