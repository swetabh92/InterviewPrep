package com.lavakumar.bowlingalley.scoreboard;

public interface ScoreBoard {

    void roll(Integer noOfPins);

    Integer score();
}
