package com.lavakumar.bowlingalley.model;

public enum Bonus {
    STRIKE,
    SPARE;
}
