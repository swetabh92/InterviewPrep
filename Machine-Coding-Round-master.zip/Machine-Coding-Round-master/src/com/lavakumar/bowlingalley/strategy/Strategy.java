package com.lavakumar.bowlingalley.strategy;

public interface Strategy {
    int bonus();
}
