package com.lavakumar.bowlingalley.constants;

public class AppConstants {
    public static final int MAX_ROLLS = 21;
    public static final int TOTAL_PINS = 10;
    public static final int TOTAL_SETS = 10;
}
