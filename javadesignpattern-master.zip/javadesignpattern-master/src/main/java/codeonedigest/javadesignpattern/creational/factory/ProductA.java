package codeonedigest.javadesignpattern.creational.factory;

public class ProductA extends Product {
}
