package codeonedigest.javadesignpattern.behavioral.visitor;

public abstract class EmployeeVisitor {
    public abstract void visit(Employee employee);
}
