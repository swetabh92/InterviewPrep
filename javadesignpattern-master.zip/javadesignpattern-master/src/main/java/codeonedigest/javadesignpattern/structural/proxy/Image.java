package codeonedigest.javadesignpattern.structural.proxy;

public interface Image {

    public void displayImage();
}
