package codeonedigest.javadesignpattern.structural.facade;

public class FacadeTest {

    public static void main(String args[]) {
        ClsOrder order = new ClsOrder();
        order.placeOrderFacadeMethod();
    }
}
