package codeonedigest.javadesignpattern.structural.bridge;

public interface IEquipment {
    void start();
    void stop();
}
