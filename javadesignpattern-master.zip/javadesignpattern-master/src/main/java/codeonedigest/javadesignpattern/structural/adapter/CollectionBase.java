package codeonedigest.javadesignpattern.structural.adapter;

public abstract class CollectionBase {
    public abstract void add(String s);
}
