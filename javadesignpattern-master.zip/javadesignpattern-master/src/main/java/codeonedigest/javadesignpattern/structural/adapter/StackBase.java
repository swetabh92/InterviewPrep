package codeonedigest.javadesignpattern.structural.adapter;

public abstract class StackBase {
    public abstract void push (String s);
}
