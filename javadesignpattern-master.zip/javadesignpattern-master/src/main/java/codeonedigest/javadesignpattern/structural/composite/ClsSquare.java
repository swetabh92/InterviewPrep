package codeonedigest.javadesignpattern.structural.composite;

public class ClsSquare implements IUserInterface {
    @Override
    public void draw() {
        System.out.println("Draw Square");
    }
}
